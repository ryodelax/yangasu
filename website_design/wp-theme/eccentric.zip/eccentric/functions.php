<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ===== テーマセットアップ =====
function eccentric_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ] );

    // メインナビゲーション登録
    register_nav_menus( [
        'primary' => 'グローバルナビゲーション',
        'footer'  => 'フッターナビゲーション',
    ] );
}
add_action( 'after_setup_theme', 'eccentric_setup' );

// ===== CSS / JS 読み込み =====
function eccentric_enqueue_assets() {
    $ver = '1.0.0';
    $uri = get_template_directory_uri();

    // Google Fonts
    wp_enqueue_style(
        'eccentric-fonts',
        'https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@300;400;500;700&family=Inter:wght@300;400;500;600&display=swap',
        [],
        null
    );

    // メインCSS
    wp_enqueue_style( 'eccentric-main', $uri . '/assets/css/main.css', [ 'eccentric-fonts' ], $ver );

    // メインJS
    wp_enqueue_script( 'eccentric-main', $uri . '/assets/js/main.js', [], $ver, true );
}
add_action( 'wp_enqueue_scripts', 'eccentric_enqueue_assets' );

// ===== Contact Form 7 が有効なときのみフォームIDを取数 =====
function eccentric_get_cf7_id() {
    if ( ! function_exists( 'wpcf7_get_contact_form_by_title' ) ) return 0;
    $form = wpcf7_get_contact_form_by_title( 'お問い合わせ' );
    return $form ? $form->id() : 0;
}
